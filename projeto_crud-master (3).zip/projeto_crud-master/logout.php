<?php
include("inc/utils.php");
logout();
include("login.php");
